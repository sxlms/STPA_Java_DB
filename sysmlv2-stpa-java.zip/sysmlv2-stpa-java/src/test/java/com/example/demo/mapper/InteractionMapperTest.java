package com.example.demo.mapper;

import com.example.demo.common.InteractionEnum;
import com.example.demo.common.UnsafeEnum;
import com.example.demo.dao.InteractionMapper;
import com.example.demo.pojo.InteractionDO;
import com.example.demo.util.SqlSessionUtil;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

import java.io.IOException;

public class InteractionMapperTest {

    @Test
    public void insertTest() throws IOException {

        SqlSession sqlSession = SqlSessionUtil.getSession();
        InteractionMapper interactionDAO = sqlSession.getMapper(InteractionMapper.class);

        long sourceControllerId = Long.valueOf(1);
        long targetControllerId = Long.valueOf(2);
        String name = "test1";
        InteractionEnum interactionEnum = InteractionEnum.CONTROLACTION;
//        boolean isSafe = false;
        UnsafeEnum unSafeEnum = UnsafeEnum.NOTPROVID;
//        long processModelVariableId = Long.valueOf(3);
//        long contextModelVariableId = Long.valueOf(4);
//        long hazardId = Long.valueOf(5);
//        long lossid = Long.valueOf(6);
//        long parentUnsafeInteractionId = Long.valueOf(7) ;
        long controlStructureId = Long.valueOf(8) ;

        InteractionDO interactionDO= new InteractionDO(name,
                interactionEnum,
                sourceControllerId,
                targetControllerId,
                controlStructureId);

        interactionDAO.insert(interactionDO);
        sqlSession.close();


    }

}
