package com.example.demo.dao;

public class InteractionDAO {

}
