package com.example.demo.common;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * This is Enum Type for unsafe control action type, which has the following value:
 * Not provided: 0
 * Provided: 1
 * Provided too early: 2
 * Provided too late:3
 * Applied too long: 4
 * Applied too short: 5
 *
 * This kind of information will be used in the database
 */

@AllArgsConstructor
@Getter
public enum UnsafeEnum {
    NOTPROVID(0,"NotProvoided"),
    PROVID(1, "Provided"),
    TOOEARLY(2, "TooEarly"),
    TOOLATE(3, "TooLate"),
    TOOLONG(4,"AppliedTooLong"),
    TOOSHORT(5,"AppliedTooShort");

    private final Integer code;
    private final String value;
    private static final Map<String, UnsafeEnum> unsafeEnumFromValue;
    private static final Map<Integer, UnsafeEnum> unsafeEnumFromCode;

    static {
        Map<String, UnsafeEnum> map = new ConcurrentHashMap<>();
        Map<Integer, UnsafeEnum> mapFromCode = new ConcurrentHashMap<>();
        for (UnsafeEnum instance : UnsafeEnum.values()) {
            map.put(instance.getValue(), instance);
            mapFromCode.put(instance.getCode(), instance);
        }
        unsafeEnumFromValue = Collections.unmodifiableMap(map);
        unsafeEnumFromCode = Collections.unmodifiableMap(mapFromCode);
    }

    public static UnsafeEnum getFromValue(String name) {
        return unsafeEnumFromValue.get(name);
    }

    public static UnsafeEnum getFromCode(Integer code) {
        return unsafeEnumFromCode.get(code);
    }
}
