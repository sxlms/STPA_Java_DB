package com.example.demo.common;

import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * This class is responsible for converting the interaction enum type to code, which can store in the database
 */

public class InteractionEnumTypeHandler extends BaseTypeHandler<InteractionEnum> {
    @Override
    public void setNonNullParameter(PreparedStatement preparedStatement, int i, InteractionEnum interactionEnum, JdbcType jdbcType)
            throws SQLException {
        preparedStatement.setInt(i, interactionEnum.getCode());

    }

    @Override
    public InteractionEnum getNullableResult(ResultSet resultSet, String interactionType) throws SQLException {
        return InteractionEnum.getFromCode(resultSet.getInt(interactionType));
    }

    @Override
    public InteractionEnum getNullableResult(ResultSet resultSet, int index) throws SQLException {
        return InteractionEnum.getFromCode(resultSet.getInt(index));
    }

    @Override
    public InteractionEnum getNullableResult(CallableStatement callableStatement, int index) throws SQLException {
        return InteractionEnum.getFromCode(callableStatement.getInt(index));
    }
}
