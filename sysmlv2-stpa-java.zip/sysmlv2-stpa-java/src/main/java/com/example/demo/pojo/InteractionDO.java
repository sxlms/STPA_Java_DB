package com.example.demo.pojo;

import com.example.demo.common.InteractionEnum;
import com.example.demo.common.UnsafeEnum;
import lombok.*;

import java.util.Date;

/**
 * The mapping interaction java object to the interaction database record
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class InteractionDO {
    private Long id;
    private String name;
    private Long sourceControllerId;
    private Long targetControllerId;
    private InteractionEnum interactionEnum;
    private Boolean isSafe;
    private UnsafeEnum unSafeEnum;
    private Long processModelVariableId;
    private Long contextModelVariableId;
    private Long hazardId;
    private Long lossId;
    private Long parentUnsafeInteractionId;
    private Integer isDelete;
    private Long controlStructureId;
    private Date gmtCreate;
    private Date gmtModified;

    /**
     * Constructor with primary key
     */
    public InteractionDO(Long id){
        this.id = id;
    }



    public InteractionDO(String name, InteractionEnum interactionEnum, long sourceControllerId, long targetControllerId, long controlStructureId) {
        this.name = name;
        this.sourceControllerId = sourceControllerId;
        this.targetControllerId = targetControllerId;
        this.interactionEnum = interactionEnum;
        this.controlStructureId = controlStructureId;
    }
}
