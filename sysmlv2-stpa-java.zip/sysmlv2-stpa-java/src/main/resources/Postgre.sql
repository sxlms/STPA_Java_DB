DROP TABLE IF EXISTS loss;
DROP SEQUENCE IF EXISTS loss_seq;
/*
 * generate the index for self-increment and update
 */
CREATE SEQUENCE loss_seq;

CREATE TABLE loss (
                    id bigint NOT NULL DEFAULT NEXTVAL ('loss_seq') ,
                    description varchar(255) NOT NULL ,
                    is_delete smallint NOT NULL DEFAULT 0 ,
                    gmt_create timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ,
                    gmt_modified timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ,
                    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS hazard;
DROP SEQUENCE IF EXISTS hazard_seq;
CREATE SEQUENCE hazard_seq;

CREATE TABLE hazard (
                    id bigint NOT NULL DEFAULT NEXTVAL ('hazard_seq'),
                    description varchar(255) NOT NULL,
                    loss_id bigint NOT NULL ,
                    is_delete smallint NOT NULL DEFAULT 0,
                    gmt_create timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    gmt_modified timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS control_structure;
DROP SEQUENCE IF EXISTS control_structure_seq;
CREATE SEQUENCE control_structure_seq;

CREATE TABLE control_structure (
                    id bigint NOT NULL DEFAULT NEXTVAL ('control_structure_seq'),
                    hazard_id bigint NOT NULL,
                    loss_id bigint NOT NULL,
                    is_delete smallint NOT NULL DEFAULT 0,
                    gmt_create timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    gmt_modified timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (id)
);


DROP TABLE IF EXISTS controller;
DROP SEQUENCE IF EXISTS controller_seq;
CREATE SEQUENCE controller_seq;

CREATE TABLE controller (
                        id bigint NOT NULL DEFAULT NEXTVAL ('controller_seq'),
                        name varchar(50) NOT NULL,
                        constructor_structure_id bigint NOT NULL,
                        is_delete smallint NOT NULL DEFAULT 0,
                        gmt_create timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ,
                        gmt_modified timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ,
                        PRIMARY KEY (id)
);

DROP TABLE IF EXISTS interaction;
DROP SEQUENCE IF EXISTS interaction_seq;
CREATE SEQUENCE interaction_seq;

CREATE TABLE interaction (
                        id bigint NOT NULL DEFAULT NEXTVAL ('interaction_seq') ,
                        name varchar(255) NOT NULL,
                        source_controller_id bigint NULL,
                        target_controller_id bigint NULL,
                        type_id smallint NOT NULL,
                        is_safe boolean NOT NULL DEFAULT true,
                        unsafe_type smallint NULL,
                        process_model_variable_id bigint NULL ,
                        context_model_variable_id bigint NULL,
                        hazard_id bigint NULL,
                        loss_id bigint NULL,
                        parent_unsafe_interaction_id bigint NULL,
                        is_delete smallint NOT NULL DEFAULT 0,
                        control_structure_id bigint NOT NULL,
                        gmt_create timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ,
                        gmt_modified timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ,
                        PRIMARY KEY (id)
);

DROP TABLE IF EXISTS process_model_variable;
DROP SEQUENCE IF EXISTS process_model_variable_seq;
CREATE SEQUENCE process_model_variable_seq;

CREATE TABLE process_model_variable (
                        id bigint NOT NULL DEFAULT NEXTVAL ('process_model_variable_seq') ,
                        name varchar(255) NOT NULL ,
                        type smallint NOT NULL DEFAULT 0,
                        is_delete smallint NOT NULL DEFAULT 0 ,
                        gmt_create timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ,
                        gmt_modified timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ,
                        PRIMARY KEY (id)
);

DROP TABLE IF EXISTS loss_scenario;
DROP SEQUENCE IF EXISTS loss_scenario_seq;
CREATE SEQUENCE loss_scenario_seq;

CREATE TABLE loss_scenario (
                             id bigint NOT NULL DEFAULT NEXTVAL ('loss_scenario_seq') ,
                             causal_factor_type smallint NOT NULL,
                             description varchar(255) NULL,
                             loss_id bigint NOT NULL ,
                             is_delete smallint NOT NULL DEFAULT 0 ,
                             gmt_create timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ,
                             gmt_modified timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ,

                             PRIMARY KEY (id)
);
/*
 * function that can be used to automatically update the modification time.
 */
CREATE OR REPLACE FUNCTION update_gmt_modified()
RETURNS TRIGGER AS $$
BEGIN
    NEW.gmt_modified = now();
RETURN NEW;
END;
$$
language 'plpgsql';

CREATE TRIGGER update_modified_time BEFORE UPDATE ON loss FOR EACH ROW EXECUTE PROCEDURE  update_gmt_modified();
CREATE TRIGGER update_modified_time BEFORE UPDATE ON hazard FOR EACH ROW EXECUTE PROCEDURE  update_gmt_modified();
CREATE TRIGGER update_modified_time BEFORE UPDATE ON controller FOR EACH ROW EXECUTE PROCEDURE  update_gmt_modified();
CREATE TRIGGER update_modified_time BEFORE UPDATE ON control_structure FOR EACH ROW EXECUTE PROCEDURE  update_gmt_modified();
CREATE TRIGGER update_modified_time BEFORE UPDATE ON interaction FOR EACH ROW EXECUTE PROCEDURE  update_gmt_modified();
CREATE TRIGGER update_modified_time BEFORE UPDATE ON process_model_variable FOR EACH ROW EXECUTE PROCEDURE  update_gmt_modified();
CREATE TRIGGER update_modified_time BEFORE UPDATE ON loss_scenario FOR EACH ROW EXECUTE PROCEDURE  update_gmt_modified();