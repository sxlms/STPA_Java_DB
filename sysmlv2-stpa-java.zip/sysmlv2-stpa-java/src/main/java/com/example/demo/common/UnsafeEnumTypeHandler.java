package com.example.demo.common;

import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * This class is responsible for converting the unsafe type to code, which can store in the database
 */

public class UnsafeEnumTypeHandler extends BaseTypeHandler<UnsafeEnum> {
    @Override
    public void setNonNullParameter(PreparedStatement preparedStatement, int i, UnsafeEnum unsafeEnum, JdbcType jdbcType)
            throws SQLException {
        preparedStatement.setInt(i, unsafeEnum.getCode());
    }

    @Override
    public UnsafeEnum getNullableResult(ResultSet resultSet, String unsafeType) throws SQLException {
        return UnsafeEnum.getFromCode(resultSet.getInt(unsafeType));
    }

    @Override
    public UnsafeEnum getNullableResult(ResultSet resultSet, int code) throws SQLException {
        return UnsafeEnum.getFromCode(resultSet.getInt(code));
    }

    @Override
    public UnsafeEnum getNullableResult(CallableStatement callableStatement, int index) throws SQLException {
        return UnsafeEnum.getFromCode(callableStatement.getInt(index));
    }
}
