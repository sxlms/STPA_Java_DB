package com.example.demo.common;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * This enum describe the type of interaction:
 * 0: feedback
 * 1: Control Action
 *
 * This kind of information will be used in the database
 */

@AllArgsConstructor
@Getter
public enum InteractionEnum {
    FEEDBACK(0, "Feedback"),
    CONTROLACTION(1, "conrtolAction");

    private final Integer code;
    private final String value;
    private static final Map<String, InteractionEnum> InteractionTypeFromValue;
    private static final Map<Integer, InteractionEnum> InteractionTypeFromCode;

    static {
        Map<String, InteractionEnum> map = new ConcurrentHashMap<>();
        Map<Integer, InteractionEnum> mapFromCode = new ConcurrentHashMap<>();
        for (InteractionEnum instance : InteractionEnum.values()) {
            map.put(instance.getValue(), instance);
            mapFromCode.put(instance.getCode(), instance);
        }
        InteractionTypeFromValue = Collections.unmodifiableMap(map);
        InteractionTypeFromCode = Collections.unmodifiableMap(mapFromCode);
    }

    public static InteractionEnum getFromValue(String name) {
        return InteractionTypeFromValue.get(name);
    }

    public static InteractionEnum getFromCode(Integer code) {
        return InteractionTypeFromCode.get(code);
    }
}
