package com.example.demo.dao;


import com.example.demo.pojo.InteractionDO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * This is the mapper file for mybatis to conduct CRUD by java program
 *
 * the path of mapper should be the same as namespace in .xml
 * the id of xml should be same as the name of method name in the interface
 */
@Mapper
public interface InteractionMapper {
    /**
     * select by the id of the interaction
     */

    InteractionDO selectByID(Long id);

    /**
     * query by the non-primary column of the interaction, put all records into a list
     * @param interactionDO:
     * @return List of interactions
     */

    List<InteractionDO> selectByInteraction(InteractionDO interactionDO);

    /**
     *
     * @param interactionDO: insert a new records into interaction table
     * @return 1: successful, as affecting row is 1
     *         0: unsuccessful
     */

    int insert(InteractionDO interactionDO);

    /**
     *
     * @param id: id of rows should be deleted
     * @return 1: successful, in the product environment, set is_delete to 1
     *         0: unsuccessful
     *
     */

    int deleteByID(Long id);


    /**
     *
     * @param interactionDO: update the corresponding interaction based on the id
     * @return 1: successful, in the product environment, set is_delete to 1
     *         0: unsuccessful
     *
     */
    int updateById(InteractionDO interactionDO);

}
